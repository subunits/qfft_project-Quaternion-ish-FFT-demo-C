# QFFT.app

This is a macOS `.app` bundle for QFFT.

## Usage
- Build `qfft` with `make` (or `make WITH_FFTW=1`) from the source project.
- Copy the compiled `qfft` binary into `QFFT.app/Contents/MacOS/`.
- Drag and drop any `.ppm` image file onto QFFT.app.
- The app will output `*_fft_R.pgm`, `*_fft_G.pgm`, and `*_fft_B.pgm` in the same folder as the input file.
- A macOS notification will confirm completion.

## Notes
- Requires macOS with Terminal and `osascript` (AppleScript) support.
- Optional: add an icon file `QFFT.icns` into `QFFT.app/Contents/Resources/` and update Info.plist accordingly.
